#include <iostream>
#include <fstream>
#include <nlohmann/json.hpp>
#include <vector>

using json = nlohmann::json;

// Employee structure
struct Employee {
    std::string id;
    std::string name;
    std::string category;
    int completed;
    std::string quality;
};

int main() {
    // Load the JSON file
    std::ifstream file("employee_data.json");
    json data;
    file >> data;

    std::vector<Employee> employees;

    // Parse JSON data and store in employees vector
    for (const auto& item : data) {
        Employee emp;
        emp.id = item["id"];
        emp.name = item["name"];
        emp.category = item["category"];
        emp.completed = item["completed"];
        emp.quality = item["quality"];
        employees.push_back(emp);
    }

    // Display the loaded data
    for (const auto& emp : employees) {
        std::cout << "Employee ID: " << emp.id << "\n"
                  << "Product Name: " << emp.name << "\n"
                  << "Category: " << emp.category << "\n"
                  << "Completed: " << emp.completed << "\n"
                  << "Quality: " << emp.quality << "\n"
                  << "-------------------------\n";
    }

    return 0;
}
