#include <gtkmm.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include "xlnt/xlnt.hpp"
#include <memory>

// Structure to store employee data
struct Employee {
    std::string id;
    std::string name;
    std::string category;
    int completed;
    std::string quality;
};

// MainWindow class
class MainWindow : public Gtk::Window {
public:
    MainWindow();
    virtual ~MainWindow();

private:
    // UI components
    Gtk::Box m_box;
    Gtk::Entry m_entry_id, m_entry_name, m_entry_completed;
    Gtk::ComboBoxText m_combobox_category, m_combobox_quality;
    Gtk::Button m_button_save, m_button_update, m_button_delete, m_button_statistics;
    Gtk::TreeView m_treeview;
    Glib::RefPtr<Gtk::ListStore> m_refTreeModel;
    
    std::vector<Employee> m_employees;

    void on_save_button_clicked();
    void on_update_button_clicked();
    void on_delete_button_clicked();
    void on_statistics_button_clicked();
    void load_data();
    void save_data();
    void generate_pdf_report();
    void save_to_excel();
    void fill_data_to_table();

    static bool compare_by_completed(Employee &a, Employee &b);
};

// Constructor
MainWindow::MainWindow()
    : m_box(Gtk::ORIENTATION_VERTICAL),
      m_button_save("Save"), m_button_update("Update"), m_button_delete("Delete"), m_button_statistics("Statistics") {

    set_title("Employee Workload Statistics System");
    set_default_size(1000, 700);

    add(m_box);

    // Create form for data input
    Gtk::Label label_id("Employee ID:");
    Gtk::Label label_name("Product Name:");
    Gtk::Label label_category("Product Category:");
    Gtk::Label label_completed("Products Completed:");
    Gtk::Label label_quality("Product Quality:");

    m_box.pack_start(label_id);
    m_box.pack_start(m_entry_id);
    m_box.pack_start(label_name);
    m_box.pack_start(m_entry_name);
    m_box.pack_start(label_category);
    m_combobox_category.append("Electronics");
    m_combobox_category.append("Furniture");
    m_combobox_category.append("Clothing");
    m_box.pack_start(m_combobox_category);
    m_box.pack_start(label_completed);
    m_box.pack_start(m_entry_completed);
    m_box.pack_start(label_quality);
    m_combobox_quality.append("High");
    m_combobox_quality.append("Medium");
    m_combobox_quality.append("Low");
    m_box.pack_start(m_combobox_quality);

    // Buttons for actions
    m_button_save.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_save_button_clicked));
    m_button_update.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_update_button_clicked));
    m_button_delete.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_delete_button_clicked));
    m_button_statistics.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_statistics_button_clicked));

    Gtk::Box *button_box = Gtk::manage(new Gtk::Box(Gtk::ORIENTATION_HORIZONTAL));
    button_box->pack_start(m_button_save);
    button_box->pack_start(m_button_update);
    button_box->pack_start(m_button_delete);
    button_box->pack_start(m_button_statistics);
    m_box.pack_start(*button_box);

    // TreeView for displaying employee data
    m_refTreeModel = Gtk::ListStore::create(m_columns);
    m_treeview.set_model(m_refTreeModel);
    m_treeview.append_column("Employee ID", m_columns.col_id);
    m_treeview.append_column("Product Name", m_columns.col_name);
    m_treeview.append_column("Category", m_columns.col_category);
    m_treeview.append_column("Completed", m_columns.col_completed);
    m_treeview.append_column("Quality", m_columns.col_quality);

    m_box.pack_start(m_treeview);

    load_data(); // Load data from file on startup

    show_all_children();
}

// Destructor
MainWindow::~MainWindow() {}

// Save employee data to CSV or Excel
void MainWindow::on_save_button_clicked() {
    Employee employee;
    employee.id = m_entry_id.get_text();
    employee.name = m_entry_name.get_text();
    employee.category = m_combobox_category.get_active_text();
    employee.completed = std::stoi(m_entry_completed.get_text());
    employee.quality = m_combobox_quality.get_active_text();

    m_employees.push_back(employee);
    save_data();
    fill_data_to_table();
}

void MainWindow::on_update_button_clicked() {
    // Logic for updating employee data
    // Similar to saving, but you replace data in vector at the right index
}

void MainWindow::on_delete_button_clicked() {
    // Logic for deleting employee data
    // Identify selected row, and remove from vector
}

void MainWindow::on_statistics_button_clicked() {
    // Sort employees by completion count (descending)
    std::sort(m_employees.begin(), m_employees.end(), compare_by_completed);

    // Generate statistics and PDF report
    generate_pdf_report();
}

void MainWindow::load_data() {
    // Load data from Excel or CSV
    // Use xlnt or another method to read Excel data
}

void MainWindow::save_data() {
    // Save employee data to Excel or CSV
    save_to_excel();
}

void MainWindow::generate_pdf_report() {
    // Generate and display PDF report using libharu or poppler
}

void MainWindow::save_to_excel() {
    xlnt::workbook wb;
    xlnt::worksheet ws = wb.active_sheet();

    int row = 1;
    for (const auto& emp : m_employees) {
        ws.cell("A" + std::to_string(row)).value(emp.id);
        ws.cell("B" + std::to_string(row)).value(emp.name);
        ws.cell("C" + std::to_string(row)).value(emp.category);
        ws.cell("D" + std::to_string(row)).value(emp.completed);
        ws.cell("E" + std::to_string(row)).value(emp.quality);
        row++;
    }

    wb.save("employee_data.xlsx");
}

void MainWindow::fill_data_to_table() {
    m_refTreeModel->clear();
    for (const auto& employee : m_employees) {
        Gtk::TreeModel::Row row = *(m_refTreeModel->append());
        row[m_columns.col_id] = employee.id;
        row[m_columns.col_name] = employee.name;
        row[m_columns.col_category] = employee.category;
        row[m_columns.col_completed] = std::to_string(employee.completed);
        row[m_columns.col_quality] = employee.quality;
    }
}

// Sort employees by completion count
bool MainWindow::compare_by_completed(Employee &a, Employee &b) {
    return a.completed > b.completed;
}

// Main function
int main(int argc, char *argv[]) {
    auto app = Gtk::Application::create(argc, argv, "org.gtkmm.employee.workload");
    MainWindow window;
    return app->run(window);
}
